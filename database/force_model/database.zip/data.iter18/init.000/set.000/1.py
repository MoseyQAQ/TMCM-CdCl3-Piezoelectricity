import numpy as np 

data = np.load("energy.npy")
print(data.shape)